
import java.util.Arrays;

import com.microsoft.z3.Z3Exception;

import it.imt.qflan.core.features.*;
import it.imt.qflan.core.features.interfaces.*;
import it.imt.qflan.core.model.*;
import it.imt.qflan.core.predicates.*;
import it.imt.qflan.core.predicates.interfaces.*;
import it.imt.qflan.core.processes.*;
import it.imt.qflan.core.processes.interfaces.*;
import it.imt.qflan.core.processes.constraints.*;
import it.imt.qflan.core.processes.actions.*;
import it.imt.qflan.core.variables.QFLanVariable;
import it.imt.qflan.core.variables.SideEffect;
			
public class AttackTree implements IQFlanModelBuilder{
	
	public AttackTree(){
			System.out.println("Model builder instantiated");
		}
	
	public QFlanModel createModel() throws Z3Exception{
		QFlanModel model = new QFlanModel();
			
		//////////////////
		/////Variables////
		//////////////////
		QFLanVariable accumulated_cost = model.addVariable("accumulated_cost", new Constant(0.0));
			
		//////////////////
		/////Features/////
		//////////////////
		//ABSTRACT FEATURES
		AbstractFeature Root = new AbstractFeature("Root");
		model.addAbstractFeatureDefinition(Root);
		AbstractFeature OpenSafe = new AbstractFeature("OpenSafe");
		model.addAbstractFeatureDefinition(OpenSafe);
		AbstractFeature LearnCombo = new AbstractFeature("LearnCombo");
		model.addAbstractFeatureDefinition(LearnCombo);
		AbstractFeature GetComboFromTarget = new AbstractFeature("GetComboFromTarget");
		model.addAbstractFeatureDefinition(GetComboFromTarget);
		AbstractFeature EavesDrop = new AbstractFeature("EavesDrop");
		model.addAbstractFeatureDefinition(EavesDrop);
		
		//CONCRETE FEATURES
		ConcreteFeature PickLock = new ConcreteFeature("PickLock");
		model.addConcreteFeatureDefinition(PickLock);
		ConcreteFeature CutOpenSafe = new ConcreteFeature("CutOpenSafe");
		model.addConcreteFeatureDefinition(CutOpenSafe);
		ConcreteFeature InstallImproperly = new ConcreteFeature("InstallImproperly");
		model.addConcreteFeatureDefinition(InstallImproperly);
		ConcreteFeature FindWrittenCombo = new ConcreteFeature("FindWrittenCombo");
		model.addConcreteFeatureDefinition(FindWrittenCombo);
		ConcreteFeature Threaten = new ConcreteFeature("Threaten");
		model.addConcreteFeatureDefinition(Threaten);
		ConcreteFeature Blackmail = new ConcreteFeature("Blackmail");
		model.addConcreteFeatureDefinition(Blackmail);
		ConcreteFeature Bribe = new ConcreteFeature("Bribe");
		model.addConcreteFeatureDefinition(Bribe);
		ConcreteFeature ListenToConversation = new ConcreteFeature("ListenToConversation");
		model.addConcreteFeatureDefinition(ListenToConversation);
		ConcreteFeature GetTargetToStateCombo = new ConcreteFeature("GetTargetToStateCombo");
		model.addConcreteFeatureDefinition(GetTargetToStateCombo);
		
		//DIAGRAM
		//Normal relation
		Root.addSon(OpenSafe);
		Root.addSon(ListenToConversation);
		
		//Normal relation
		OpenSafe.addSon(PickLock);
		OpenSafe.addSon(LearnCombo);
		OpenSafe.addSon(CutOpenSafe);
		OpenSafe.addSon(InstallImproperly);
		
		//Normal relation
		GetComboFromTarget.addSon(Threaten);
		GetComboFromTarget.addSon(Blackmail);
		GetComboFromTarget.addSon(EavesDrop);
		GetComboFromTarget.addSon(Bribe);
		
		//Normal relation
		LearnCombo.addSon(FindWrittenCombo);
		LearnCombo.addSon(GetComboFromTarget);
		
		//Normal relation
		EavesDrop.addSon(GetTargetToStateCombo);
		
		model.computeDescendantsAndAncestors();
		
		////////////////////////////
		//Hierarchical constraints//
		////////////////////////////
			
		/////////////////////////////
		////CrossTree Constraints////
		/////////////////////////////
		model.addConstraint(new FeatureRequireConstraint(GetTargetToStateCombo, ListenToConversation,model));
		
			
		//////////////////
		////Predicates////
		//////////////////
		IPredicateDef cost = new PredicateDef("cost");
		model.addPredicateDef(cost);
		cost.setValue(PickLock,30.0);
		cost.setValue(CutOpenSafe,10.0);
		cost.setValue(InstallImproperly,100.0);
		cost.setValue(FindWrittenCombo,75.0);
		cost.setValue(Threaten,60.0);
		cost.setValue(Blackmail,100.0);
		cost.setValue(Bribe,20.0);
		cost.setValue(ListenToConversation,20.0);
		cost.setValue(GetTargetToStateCombo,40.0);
		
		
		////////////////////////////////
		////Quantitative Constraints////
		////////////////////////////////
		model.addConstraint(new DisequationOfPredicateExpressions(new Predicate(cost, Root),new Constant(100.0),PredicateExprComparator.LEQ));
		model.addConstraint(new DisequationOfPredicateExpressions(accumulated_cost,new Constant(10.0),PredicateExprComparator.LEQ));
		
		
		///////////////
		////Actions////
		///////////////
		NormalAction tryAction = new NormalAction("tryAction");
		model.addNormalAction(tryAction);
		NormalAction fail = new NormalAction("fail");
		model.addNormalAction(fail);
		
		//////////////////////////
		////Action constraints////
		//////////////////////////
		model.addActionConstraint(new ActionRequiresConstraint(tryAction, new NotConstraintExpr(new HasFeature(OpenSafe,model))));
		model.addActionConstraint(new ActionRequiresConstraint(new InstallAction(PickLock,true), new NotConstraintExpr(new HasFeature(OpenSafe,model))));
		model.addActionConstraint(new ActionRequiresConstraint(new InstallAction(CutOpenSafe,true), new NotConstraintExpr(new HasFeature(OpenSafe,model))));
		model.addActionConstraint(new ActionRequiresConstraint(new InstallAction(InstallImproperly,true), new NotConstraintExpr(new HasFeature(OpenSafe,model))));
		model.addActionConstraint(new ActionRequiresConstraint(new InstallAction(FindWrittenCombo,true), new NotConstraintExpr(new HasFeature(OpenSafe,model))));
		model.addActionConstraint(new ActionRequiresConstraint(new InstallAction(Threaten,true), new NotConstraintExpr(new HasFeature(OpenSafe,model))));
		model.addActionConstraint(new ActionRequiresConstraint(new InstallAction(Blackmail,true), new NotConstraintExpr(new HasFeature(OpenSafe,model))));
		model.addActionConstraint(new ActionRequiresConstraint(new InstallAction(Bribe,true), new NotConstraintExpr(new HasFeature(OpenSafe,model))));
		model.addActionConstraint(new ActionRequiresConstraint(new InstallAction(ListenToConversation,true), new NotConstraintExpr(new HasFeature(OpenSafe,model))));
		model.addActionConstraint(new ActionRequiresConstraint(new InstallAction(GetTargetToStateCombo,true), new NotConstraintExpr(new HasFeature(OpenSafe,model))));
		
		//In order to use a feature, it must be installed. These constraints are already built-in
		//( do(PickLock) -> has(PickLock))
		//( do(CutOpenSafe) -> has(CutOpenSafe))
		//( do(InstallImproperly) -> has(InstallImproperly))
		//( do(FindWrittenCombo) -> has(FindWrittenCombo))
		//( do(Threaten) -> has(Threaten))
		//( do(Blackmail) -> has(Blackmail))
		//( do(Bribe) -> has(Bribe))
		//( do(ListenToConversation) -> has(ListenToConversation))
		//( do(GetTargetToStateCombo) -> has(GetTargetToStateCombo))
		
		/////////////////////////////
		////Processes definitions////
		/////////////////////////////
		
		ProcessDefinition idle = new ProcessDefinition("idle");
		ProcessDefinition idleFailing = new ProcessDefinition("idleFailing");
		ProcessDefinition tryPickLock = new ProcessDefinition("tryPickLock");
		ProcessDefinition tryCutOpenSafe = new ProcessDefinition("tryCutOpenSafe");
		ProcessDefinition tryInstallImproperly = new ProcessDefinition("tryInstallImproperly");
		ProcessDefinition tryFindWrittenCombo = new ProcessDefinition("tryFindWrittenCombo");
		ProcessDefinition tryThreaten = new ProcessDefinition("tryThreaten");
		ProcessDefinition tryBlackmail = new ProcessDefinition("tryBlackmail");
		ProcessDefinition tryListenToConversation = new ProcessDefinition("tryListenToConversation");
		ProcessDefinition tryGetTargetToStateCombo = new ProcessDefinition("tryGetTargetToStateCombo");
		ProcessDefinition tryBribe = new ProcessDefinition("tryBribe");
		
		model.addProcessDefinition(idle, QFlanModel.makeMultiChoice(Arrays.asList((IProcess)new Prefix(1.0,new InstallAction(PickLock,true),new SideEffect[]{},idle), (IProcess)new Prefix(1.0,new InstallAction(CutOpenSafe,true),new SideEffect[]{},idle), (IProcess)new Prefix(1.0,new InstallAction(InstallImproperly,true),new SideEffect[]{},idle), (IProcess)new Prefix(1.0,new InstallAction(FindWrittenCombo,true),new SideEffect[]{},idle), (IProcess)new Prefix(1.0,new InstallAction(Threaten,true),new SideEffect[]{},idle), (IProcess)new Prefix(1.0,new InstallAction(Blackmail,true),new SideEffect[]{},idle), (IProcess)new Prefix(1.0,new InstallAction(ListenToConversation,true),new SideEffect[]{},idle), (IProcess)new Prefix(1.0,new InstallAction(GetTargetToStateCombo,true),new SideEffect[]{},idle), (IProcess)new Prefix(1.0,new InstallAction(Bribe,true),new SideEffect[]{},idle))));
		model.addProcessDefinition(idleFailing, QFlanModel.makeMultiChoice(Arrays.asList((IProcess)new Prefix(1.0,tryAction,new SideEffect[]{new SideEffect(accumulated_cost,new ArithmeticPredicateExpr(accumulated_cost,new Constant(1.0),ArithmeticOperation.SUM))},tryPickLock), (IProcess)new Prefix(1.0,tryAction,new SideEffect[]{new SideEffect(accumulated_cost,new ArithmeticPredicateExpr(accumulated_cost,new Constant(1.0),ArithmeticOperation.SUM))},tryCutOpenSafe), (IProcess)new Prefix(1.0,tryAction,new SideEffect[]{new SideEffect(accumulated_cost,new ArithmeticPredicateExpr(accumulated_cost,new Constant(1.0),ArithmeticOperation.SUM))},tryInstallImproperly), (IProcess)new Prefix(1.0,tryAction,new SideEffect[]{new SideEffect(accumulated_cost,new ArithmeticPredicateExpr(accumulated_cost,new Constant(1.0),ArithmeticOperation.SUM))},tryFindWrittenCombo), (IProcess)new Prefix(1.0,tryAction,new SideEffect[]{new SideEffect(accumulated_cost,new ArithmeticPredicateExpr(accumulated_cost,new Constant(1.0),ArithmeticOperation.SUM))},tryThreaten), (IProcess)new Prefix(1.0,tryAction,new SideEffect[]{new SideEffect(accumulated_cost,new ArithmeticPredicateExpr(accumulated_cost,new Constant(1.0),ArithmeticOperation.SUM))},tryBlackmail), (IProcess)new Prefix(1.0,tryAction,new SideEffect[]{new SideEffect(accumulated_cost,new ArithmeticPredicateExpr(accumulated_cost,new Constant(1.0),ArithmeticOperation.SUM))},tryListenToConversation), (IProcess)new Prefix(1.0,tryAction,new SideEffect[]{new SideEffect(accumulated_cost,new ArithmeticPredicateExpr(accumulated_cost,new Constant(1.0),ArithmeticOperation.SUM))},tryGetTargetToStateCombo), (IProcess)new Prefix(1.0,tryAction,new SideEffect[]{new SideEffect(accumulated_cost,new ArithmeticPredicateExpr(accumulated_cost,new Constant(1.0),ArithmeticOperation.SUM))},tryBribe))));
		model.addProcessDefinition(tryPickLock, QFlanModel.makeMultiChoice(Arrays.asList((IProcess)new Prefix(1.0,new InstallAction(PickLock,true),new SideEffect[]{},idleFailing), (IProcess)new Prefix(10.0,fail,new SideEffect[]{},idleFailing))));
		model.addProcessDefinition(tryCutOpenSafe, QFlanModel.makeMultiChoice(Arrays.asList((IProcess)new Prefix(1.0,new InstallAction(CutOpenSafe,true),new SideEffect[]{},idleFailing), (IProcess)new Prefix(10.0,fail,new SideEffect[]{},idleFailing))));
		model.addProcessDefinition(tryInstallImproperly, QFlanModel.makeMultiChoice(Arrays.asList((IProcess)new Prefix(1.0,new InstallAction(InstallImproperly,true),new SideEffect[]{},idleFailing), (IProcess)new Prefix(10.0,fail,new SideEffect[]{},idleFailing))));
		model.addProcessDefinition(tryFindWrittenCombo, QFlanModel.makeMultiChoice(Arrays.asList((IProcess)new Prefix(1.0,new InstallAction(FindWrittenCombo,true),new SideEffect[]{},idleFailing), (IProcess)new Prefix(10.0,fail,new SideEffect[]{},idleFailing))));
		model.addProcessDefinition(tryThreaten, QFlanModel.makeMultiChoice(Arrays.asList((IProcess)new Prefix(1.0,new InstallAction(Threaten,true),new SideEffect[]{},idleFailing), (IProcess)new Prefix(10.0,fail,new SideEffect[]{},idleFailing))));
		model.addProcessDefinition(tryBlackmail, QFlanModel.makeMultiChoice(Arrays.asList((IProcess)new Prefix(1.0,new InstallAction(Blackmail,true),new SideEffect[]{},idleFailing), (IProcess)new Prefix(10.0,fail,new SideEffect[]{},idleFailing))));
		model.addProcessDefinition(tryListenToConversation, QFlanModel.makeMultiChoice(Arrays.asList((IProcess)new Prefix(1.0,new InstallAction(ListenToConversation,true),new SideEffect[]{},idleFailing), (IProcess)new Prefix(10.0,fail,new SideEffect[]{},idleFailing))));
		model.addProcessDefinition(tryGetTargetToStateCombo, QFlanModel.makeMultiChoice(Arrays.asList((IProcess)new Prefix(1.0,new InstallAction(GetTargetToStateCombo,true),new SideEffect[]{},idleFailing), (IProcess)new Prefix(10.0,fail,new SideEffect[]{},idleFailing))));
		model.addProcessDefinition(tryBribe, QFlanModel.makeMultiChoice(Arrays.asList((IProcess)new Prefix(1.0,new InstallAction(Bribe,true),new SideEffect[]{},idleFailing), (IProcess)new Prefix(10.0,fail,new SideEffect[]{},idleFailing))));
		
		/////////////////////////////////////////////////
		////Initially installed features and Process ////
		/////////////////////////////////////////////////
		model.setInitialState(Arrays.asList(), idleFailing);
		model.resetToInitialState();
		return model;		
	}
}
			
			


import java.util.Arrays;

import com.microsoft.z3.Z3Exception;

import it.imt.qflan.core.features.*;
import it.imt.qflan.core.features.interfaces.*;
import it.imt.qflan.core.model.*;
import it.imt.qflan.core.predicates.*;
import it.imt.qflan.core.predicates.interfaces.*;
import it.imt.qflan.core.processes.*;
import it.imt.qflan.core.processes.interfaces.*;
import it.imt.qflan.core.processes.constraints.*;
import it.imt.qflan.core.processes.actions.*;
import it.imt.qflan.core.variables.QFLanVariable;
import it.imt.qflan.core.variables.SideEffect;
			
public class VendingMachine implements IQFlanModelBuilder{
	
	public VendingMachine(){
			System.out.println("Model builder instantiated");
		}
	
	public QFlanModel createModel() throws Z3Exception{
		QFlanModel model = new QFlanModel();
			
		//////////////////
		/////Variables////
		//////////////////
		QFLanVariable sold = model.addVariable("sold", new Constant(0.0));
		QFLanVariable deploys = model.addVariable("deploys", new Constant(0.0));
			
		//////////////////
		/////Features/////
		//////////////////
		//ABSTRACT FEATURES
		AbstractFeature Machine = new AbstractFeature("Machine");
		model.addAbstractFeatureDefinition(Machine);
		AbstractFeature Beverage = new AbstractFeature("Beverage");
		model.addAbstractFeatureDefinition(Beverage);
		AbstractFeature CoffeeBased = new AbstractFeature("CoffeeBased");
		model.addAbstractFeatureDefinition(CoffeeBased);
		
		//CONCRETE FEATURES
		ConcreteFeature Cocoa = new ConcreteFeature("Cocoa");
		model.addConcreteFeatureDefinition(Cocoa);
		ConcreteFeature Tea = new ConcreteFeature("Tea");
		model.addConcreteFeatureDefinition(Tea);
		ConcreteFeature Cappuccino = new ConcreteFeature("Cappuccino");
		model.addConcreteFeatureDefinition(Cappuccino);
		ConcreteFeature Coffee = new ConcreteFeature("Coffee");
		model.addConcreteFeatureDefinition(Coffee);
		
		//DIAGRAM
		//Normal relation
		Machine.addSon(Cocoa);
		Machine.addSon(Beverage);
		Beverage.setOptional(false);
		
		//XOR relation
		Beverage.addSon(CoffeeBased);
		Beverage.addSon(Tea);
		
		//OR relation
		CoffeeBased.addSon(Cappuccino);
		CoffeeBased.addSon(Coffee);
		
		model.computeDescendantsAndAncestors();
		
		////////////////////////////
		//Hierarchical constraints//
		////////////////////////////
		model.addConstraint(new HasFeature(Beverage,model,true));
		model.addConstraint(new Alternative_OrConstraint(Beverage,Arrays.asList((IFeature)CoffeeBased,(IFeature)Tea), Alternative_ORCondition.XOR,model));
		model.addConstraint(new Alternative_OrConstraint(CoffeeBased,Arrays.asList((IFeature)Cappuccino,(IFeature)Coffee), Alternative_ORCondition.OR,model));
			
		/////////////////////////////
		////CrossTree Constraints////
		/////////////////////////////
		model.addConstraint(new FeatureRequireConstraint(Cappuccino, Coffee,model));
		model.addConstraint(new FeatureSetConstraint(Arrays.asList((IFeature)Tea,(IFeature)Cocoa), FeatureSetCondition.ATMOSTONE,model));
		
			
		//////////////////
		////Predicates////
		//////////////////
		IPredicateDef price = new PredicateDef("price");
		model.addPredicateDef(price);
		price.setValue(Cocoa,2.0);
		price.setValue(Cappuccino,7.0);
		price.setValue(Coffee,5.0);
		price.setValue(Tea,5.0);
		
		
		////////////////////////////////
		////Quantitative Constraints////
		////////////////////////////////
		model.addConstraint(new DisequationOfPredicateExpressions(new Predicate(price, Machine),new Constant(15.0),PredicateExprComparator.LEQ));
		
		
		///////////////
		////Actions////
		///////////////
		NormalAction sell = new NormalAction("sell");
		model.addNormalAction(sell);
		NormalAction deploy = new NormalAction("deploy");
		model.addNormalAction(deploy);
		NormalAction reconfigure = new NormalAction("reconfigure");
		model.addNormalAction(reconfigure);
		NormalAction serveCoffee = new NormalAction("serveCoffee");
		model.addNormalAction(serveCoffee);
		NormalAction serveCappuccino = new NormalAction("serveCappuccino");
		model.addNormalAction(serveCappuccino);
		NormalAction serveChocaccino = new NormalAction("serveChocaccino");
		model.addNormalAction(serveChocaccino);
		NormalAction serveTea = new NormalAction("serveTea");
		model.addNormalAction(serveTea);
		NormalAction chocaccino = new NormalAction("chocaccino");
		model.addNormalAction(chocaccino);
		
		//////////////////////////
		////Action constraints////
		//////////////////////////
		model.addActionConstraint(new ActionRequiresConstraint(chocaccino, new BooleanConstraintExpr(new HasFeature(Cappuccino,model),new HasFeature(Cocoa,model),BooleanConnector.AND)));
		
		//In order to use a feature, it must be installed. These constraints are already built-in
		//( do(Cocoa) -> has(Cocoa))
		//( do(Tea) -> has(Tea))
		//( do(Cappuccino) -> has(Cappuccino))
		//( do(Coffee) -> has(Coffee))
		
		/////////////////////////////
		////Processes definitions////
		/////////////////////////////
		
		ProcessDefinition factory = new ProcessDefinition("factory");
		ProcessDefinition deposit = new ProcessDefinition("deposit");
		ProcessDefinition operating = new ProcessDefinition("operating");
		ProcessDefinition prepareCoffee = new ProcessDefinition("prepareCoffee");
		ProcessDefinition prepareCappuccino = new ProcessDefinition("prepareCappuccino");
		ProcessDefinition prepareTea = new ProcessDefinition("prepareTea");
		ProcessDefinition prepareChocaccino = new ProcessDefinition("prepareChocaccino");
		
		model.addProcessDefinition(factory, QFlanModel.makeMultiChoice(Arrays.asList((IProcess)new Prefix(20.0,new ReplaceAction(Coffee,Tea),new SideEffect[]{},factory), (IProcess)new Prefix(10.0,new InstallAction(Cocoa,true),new SideEffect[]{},factory), (IProcess)new Prefix(10.0,new InstallAction(Cappuccino,true),new SideEffect[]{},factory), (IProcess)new Prefix(1.0,sell,new SideEffect[]{new SideEffect(sold,new Constant(1.0))},deposit))));
		model.addProcessDefinition(deposit, QFlanModel.makeMultiChoice(Arrays.asList((IProcess)new Prefix(2.0,new InstallAction(Cappuccino,true),new SideEffect[]{},deposit), (IProcess)new Prefix(2.0,new InstallAction(Cappuccino,false),new SideEffect[]{},deposit), (IProcess)new Prefix(2.0,new InstallAction(Cocoa,true),new SideEffect[]{},deposit), (IProcess)new Prefix(2.0,new InstallAction(Cocoa,false),new SideEffect[]{},deposit), (IProcess)new Prefix(2.0,deploy,new SideEffect[]{new SideEffect(deploys,new ArithmeticPredicateExpr(deploys,new Constant(1.0),ArithmeticOperation.SUM))},operating))));
		model.addProcessDefinition(operating, QFlanModel.makeMultiChoice(Arrays.asList((IProcess)new Prefix(3.0,Coffee,new SideEffect[]{},prepareCoffee), (IProcess)new Prefix(3.0,Cappuccino,new SideEffect[]{},prepareCappuccino), (IProcess)new Prefix(2.0,chocaccino,new SideEffect[]{},prepareChocaccino), (IProcess)new Prefix(3.0,Tea,new SideEffect[]{},prepareTea), (IProcess)new Prefix(1.0,reconfigure,new SideEffect[]{},deposit))));
		model.addProcessDefinition(prepareCoffee, QFlanModel.makeMultiChoice(Arrays.asList((IProcess)new Prefix(1.0,serveCoffee,new SideEffect[]{},operating))));
		model.addProcessDefinition(prepareCappuccino, QFlanModel.makeMultiChoice(Arrays.asList((IProcess)new Prefix(1.0,serveCappuccino,new SideEffect[]{},operating), (IProcess)new Prefix(1.0,serveTea,new SideEffect[]{},operating))));
		model.addProcessDefinition(prepareTea, ZeroProcess.ZERO);
		model.addProcessDefinition(prepareChocaccino, QFlanModel.makeMultiChoice(Arrays.asList((IProcess)new Prefix(1.0,serveChocaccino,new SideEffect[]{},operating))));
		
		/////////////////////////////////////////////////
		////Initially installed features and Process ////
		/////////////////////////////////////////////////
		model.setInitialState(Arrays.asList(Coffee), factory);
		model.resetToInitialState();
		return model;		
	}
}
			
			
